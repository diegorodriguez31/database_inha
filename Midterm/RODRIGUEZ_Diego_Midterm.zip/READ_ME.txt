This archive contains all my work for the database midterm assignment.

You can find the following files:
- Database_model.jpg: a screenshot of the database model
- midterm.sql: file containing all the scripts necessary (creation table,
triggers, printing, tests...)
- ITS_model.loo: Looping file of the database model
Looping is the application I used in France in my University for creating databases
- RODRIGUEZ_Diego_Database_midterm.ipynb: Google colab file containing all the report and the scripts
Indeed, I decided to write my report directly in the Google Colab file.

My GitHub link: https://github.com/diegorodriguez31/database_inha/tree/main/Midterm
